// Deprecated - replaced by RecommendationRequestFactory
