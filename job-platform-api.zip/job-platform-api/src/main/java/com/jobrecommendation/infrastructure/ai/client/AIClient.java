// Deprecated - duplicate of ResumeAiClient
